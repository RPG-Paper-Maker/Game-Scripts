/*
    RPG Paper Maker Copyright (C) 2017-2019 Wano

    RPG Paper Maker engine is under proprietary license.
    This source code is also copyrighted.

    Use Commercial edition for commercial use of your games.
    See RPG Paper Maker EULA here:
        http://rpg-paper-maker.com/index.php/eula.
*/

// -------------------------------------------------------
//
//  CLASS SceneBattle
//
//  Step 0 : Initialization of the battle, camera movment (transition),
//  allies/ennemies comming.
//
// -------------------------------------------------------

SceneBattle.prototype.initializeStep0 = function() {
    this.winning = false;
    this.kindSelection = CharacterKind.Hero;
    this.selectedUserIndex = 0;
    this.selectedTargetIndex = 0;
    this.battleCommandKind = EffectSpecialActionKind.None;
    this.targets = [];
    this.damages = [];
    this.battlers = new Array(2);
    this.graphicPlayers = new Array(2);

    this.initializeAlliesBattlers();
    this.initializeEnemiesBattlers();
    this.initializeInformations();
    this.initializeWindowCommands();
    this.initializeMusics();
    this.initializeWindowsEnd();
};

// -------------------------------------------------------

SceneBattle.prototype.initializeAlliesBattlers = function() {
    var i, l, position, battler;

    l = $game.teamHeroes.length;
    this.battlers[CharacterKind.Hero] = new Array(l);
    this.graphicPlayers[CharacterKind.Hero] = new Array(l);
    for (i = 0; i < l; i++) {

        // Battlers
        position = new THREE.Vector3($game.heroBattle.position.x + (2 *
            $SQUARE_SIZE) + (i * $SQUARE_SIZE / 2), $game.heroBattle.position.y, 
            $game.heroBattle.position.z - $SQUARE_SIZE + (i * $SQUARE_SIZE));
        battler = new Battler($game.teamHeroes[i], position, this.camera);
        battler.addToScene();
        this.battlers[CharacterKind.Hero][i] = battler;

        // Graphic player
        this.graphicPlayers[CharacterKind.Hero][i] = {
            user: new GraphicPlayer(battler.character, false),
            target: new GraphicPlayer(battler.character, true)
        };
    }
};

// -------------------------------------------------------

SceneBattle.prototype.initializeEnemiesBattlers = function() {
    var i, l, troop, enemy, position, instancied, battler;

    troop = $datasGame.troops.list[this.troopID];
    l = troop.list.length;
    this.battlers[CharacterKind.Monster] = new Array(l);
    this.graphicPlayers[CharacterKind.Monster] = new Array(l);
    for (i = 0; i < l; i++) {

        // Battlers
        enemy = troop.list[i];
        position = new THREE.Vector3($game.heroBattle.position.x - (2 *
            $SQUARE_SIZE) - (i * $SQUARE_SIZE * 3 / 4), $game.heroBattle
            .position.y, $game.heroBattle.position.z - $SQUARE_SIZE + (i *
            $SQUARE_SIZE));
        instancied = new GamePlayer(CharacterKind.Monster, enemy.id, $game
            .charactersInstances++, []);
        instancied.instanciate(enemy.level);
        battler = new Battler(instancied, position, this.camera);
        battler.addToScene();
        this.battlers[CharacterKind.Monster][i] = battler;

        // Graphic player
        this.graphicPlayers[CharacterKind.Monster][i] = {
            target: new GraphicPlayer(battler.character, true)
        };
    }
};

// -------------------------------------------------------

SceneBattle.prototype.initializeInformations = function() {
    this.windowTopInformations = new WindowBox(0, RPM.HUGE_SPACE, $SCREEN_X, RPM
        .SMALL_SLOT_HEIGHT, null, RPM.SMALL_SLOT_PADDING);
    this.windowUserInformations = new WindowBox($SCREEN_X - SceneBattle
        .WINDOW_PROFILE_WIDTH, $SCREEN_Y - SceneBattle.WINDOW_PROFILE_HEIGHT,
        SceneBattle.WINDOW_PROFILE_WIDTH, SceneBattle.WINDOW_PROFILE_HEIGHT, 
        null, RPM.SMALL_PADDING_BOX, false);
    this.windowTargetInformations = new WindowBox(0, $SCREEN_Y - SceneBattle
        .WINDOW_PROFILE_HEIGHT, SceneBattle.WINDOW_PROFILE_WIDTH, SceneBattle
        .WINDOW_PROFILE_HEIGHT, null, RPM.SMALL_PADDING_BOX, false);
};

// -------------------------------------------------------

SceneBattle.prototype.initializeWindowCommands = function() {
    var i, l, listContent, listCallbacks, skill;

    l = $datasGame.battleSystem.battleCommandsOrder.length;
    listContent = new Array(l);
    listCallbacks = new Array(l);
    for (i = 0; i < l; i++) {
        skill = $datasGame.skills.list[$datasGame.battleSystem
            .battleCommandsOrder[i]];
        listContent[i] = new GraphicTextIcon(skill.name, skill.pictureID);
        listContent[i].skill = skill;
        listCallbacks[i] = SystemCommonSkillItem.prototype.use;
    }
    this.windowChoicesBattleCommands = new WindowChoices(OrientationWindow
        .Vertical, RPM.HUGE_SPACE, $SCREEN_Y - RPM.HUGE_SPACE - (l * RPM
        .SMALL_SLOT_HEIGHT), SceneBattle.WINDOW_COMMANDS_WIDTH, RPM
        .SMALL_SLOT_HEIGHT, SceneBattle.COMMANDS_NUMBER, listContent, 
        listCallbacks, RPM.SMALL_SLOT_PADDING);
    this.windowChoicesSkills = new WindowChoices(OrientationWindow.Vertical, 
        SceneBattle.WINDOW_COMMANDS_SELECT_X, SceneBattle
        .WINDOW_COMMANDS_SELECT_Y, SceneBattle.WINDOW_COMMANDS_SELECT_WIDTH, RPM
        .SMALL_SLOT_HEIGHT, SceneBattle.COMMANDS_NUMBER, [], null, RPM
        .SMALL_SLOT_PADDING);
    this.windowSkillDescription = new WindowBox($SCREEN_X - SceneBattle
        .WINDOW_DESCRIPTIONS_X, SceneBattle.WINDOW_DESCRIPTIONS_Y, SceneBattle
        .WINDOW_DESCRIPTIONS_WIDTH, SceneBattle.WINDOW_DESCRIPTIONS_HEIGHT, null
        , RPM.HUGE_PADDING_BOX);
    this.windowChoicesItems = new WindowChoices(OrientationWindow.Vertical, 
        SceneBattle.WINDOW_COMMANDS_SELECT_X, SceneBattle
        .WINDOW_COMMANDS_SELECT_Y, SceneBattle.WINDOW_COMMANDS_SELECT_WIDTH, RPM
        .SMALL_SLOT_HEIGHT, SceneBattle.COMMANDS_NUMBER, [], null, RPM
        .SMALL_SLOT_PADDING);
    this.windowItemDescription = new WindowBox($SCREEN_X - SceneBattle
        .WINDOW_DESCRIPTIONS_X, SceneBattle.WINDOW_DESCRIPTIONS_Y, SceneBattle
        .WINDOW_DESCRIPTIONS_WIDTH, SceneBattle.WINDOW_DESCRIPTIONS_HEIGHT, null
        , RPM.HUGE_PADDING_BOX);
};

// -------------------------------------------------------

SceneBattle.prototype.initializeMusics = function() {
    SceneBattle.musicMap = SystemPlaySong.currentPlayingMusic;
    SceneBattle.musicMapTime = $songsManager.getPlayer(SongKind.Music).position
        / RPM.ONE_SECOND_MILLI;
    $datasGame.battleSystem.battleMusic.playSong();
};


// -------------------------------------------------------

SceneBattle.prototype.initializeWindowsEnd = function() {
    this.windowExperienceProgression = new WindowBox(SceneBattle
        .WINDOW_EXPERIENCE_X, SceneBattle.WINDOW_EXPERIENCE_Y, SceneBattle
        .WINDOW_EXPERIENCE_WIDTH, (SceneBattle.WINDOW_EXPERIENCE_HEIGHT * $game
        .teamHeroes.length) + RPM.SMALL_PADDING_BOX[2] + RPM.SMALL_PADDING_BOX
        [3], new GraphicXPProgression(), RPM.SMALL_PADDING_BOX);
    this.windowStatisticProgression = new WindowBox(SceneBattle.WINDOW_STATS_X, 
        SceneBattle.WINDOW_STATS_Y, SceneBattle.WINDOW_STATS_WIDTH, SceneBattle
        .WINDOW_STATS_HEIGHT, null, RPM.HUGE_PADDING_BOX);
};

// -------------------------------------------------------

SceneBattle.prototype.updateStep0 = function() {
    $requestPaintHUD = true;

    this.updateTransitionStartFade();
    this.updateTransitionStartZoom();
};

// -------------------------------------------------------

SceneBattle.prototype.updateTransitionStartFade = function() {
    if (this.transitionStart === MapTransitionKind.Fade) {
        if (this.transitionColor) {
            this.transitionColorAlpha += SceneBattle.TRANSITION_COLOR_VALUE;
            if (this.transitionColorAlpha >= 1) {
                this.transitionColorAlpha = 1;
                this.transitionColor = false;
                this.timeTransition = new Date().getTime();
                this.updateBackgroundColor();
            }
            return;
        }
        if (new Date().getTime() - this.timeTransition < SceneBattle
            .TRANSITION_COLOR_END_WAIT)
        {
            return;
        }
        if (this.transitionColorAlpha > 0) {
            this.transitionColorAlpha -= SceneBattle.TRANSITION_COLOR_VALUE;
            if (this.transitionColorAlpha <= 0) {
                this.transitionColorAlpha = 0;
            }
            return;
        }

        this.changeStep(1);
    }
};

// -------------------------------------------------------

SceneBattle.prototype.updateTransitionStartZoom = function() {
    if (this.transitionStart === MapTransitionKind.Zoom) {
        if (this.transitionZoom) {
            this.sceneMap.camera.distance -= SceneBattle.TRANSITION_ZOOM_UDPATE;
            if (this.sceneMap.camera.distance <= SceneBattle
                .START_CAMERA_DISTANCE) 
            {
                this.sceneMap.camera.distance = SceneBattle
                    .START_CAMERA_DISTANCE;
                this.transitionZoom = false;
                this.updateBackgroundColor();
            }
            this.sceneMap.camera.update();
            return;
        }
        if (this.camera.distance < SceneBattle.CAMERA_DISTANCE) {
            this.camera.distance += SceneBattle.TRANSITION_ZOOM_UDPATE;
            if (this.camera.distance >= SceneBattle.CAMERA_DISTANCE) {
                this.camera.distance = SceneBattle.CAMERA_DISTANCE;
                this.cameraON = true;
            } else {
                return;
            }
        }

        this.changeStep(1);
    }
};

// -------------------------------------------------------

SceneBattle.prototype.onKeyPressedStep0 = function(key){

};

// -------------------------------------------------------

SceneBattle.prototype.onKeyReleasedStep0 = function(key){

};

// -------------------------------------------------------

SceneBattle.prototype.onKeyPressedRepeatStep0 = function(key){

};

// -------------------------------------------------------

SceneBattle.prototype.onKeyPressedAndRepeatStep0 = function(key){

};

// -------------------------------------------------------

SceneBattle.prototype.drawHUDStep0 = function() {
    if (this.transitionStart === 1) {
        $context.fillStyle = RPM.STRING_RGBA + RPM.STRING_PARENTHESIS_LEFT + 
            this.transitionStartColor.red + RPM.STRING_COMA + this
            .transitionStartColor.green + RPM.STRING_COMA + this
            .transitionStartColor.blue + RPM.STRING_COMA + this
            .transitionColorAlpha + RPM.STRING_PARENTHESIS_RIGHT;
        $context.fillRect(0, 0, $canvasWidth, $canvasHeight);
    }
};
